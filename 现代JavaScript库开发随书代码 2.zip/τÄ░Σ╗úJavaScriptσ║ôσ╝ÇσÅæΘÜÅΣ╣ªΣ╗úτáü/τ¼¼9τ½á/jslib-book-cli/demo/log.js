console.error('失败消息')
console.warn('警告类消息')
console.info('提示类消息')
console.log('普通消息')