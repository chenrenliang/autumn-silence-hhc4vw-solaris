const chalk = require('chalk');
console.log(chalk.red('红色字体'));
console.log(chalk.red.bgGreen('绿底红字'));
console.log(chalk.bold('加粗'));
console.log(chalk.underline('下划线'));