var expect = require("expect.js");

describe("c", function () {
    this.timeout(1000);
    it("单元测试", function () {});
});
