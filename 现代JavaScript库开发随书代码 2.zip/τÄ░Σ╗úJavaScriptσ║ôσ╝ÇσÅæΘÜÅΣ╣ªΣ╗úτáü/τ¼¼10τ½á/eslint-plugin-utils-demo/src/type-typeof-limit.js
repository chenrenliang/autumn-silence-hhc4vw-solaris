typeof a === 'object';
