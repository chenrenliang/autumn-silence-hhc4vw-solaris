import { range, pick } from '@jslib-book/utils';

console.log(range, pick);
