import { truncate, pick } from '@jslib-book/utils';

console.log(truncate, pick);
