export default [
  require('/Users/yan/jslib-book-root/utils/docs/node_modules/infima/dist/css/default/default.css'),
  require('/Users/yan/jslib-book-root/utils/docs/node_modules/@docusaurus/theme-classic/lib/prism-include-languages'),
  require('/Users/yan/jslib-book-root/utils/docs/node_modules/@docusaurus/theme-classic/lib/admonitions.css'),
  require('/Users/yan/jslib-book-root/utils/docs/src/css/custom.css'),
];
