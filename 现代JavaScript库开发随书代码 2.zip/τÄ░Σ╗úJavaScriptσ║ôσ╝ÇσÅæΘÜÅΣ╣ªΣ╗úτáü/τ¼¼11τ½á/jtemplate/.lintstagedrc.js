module.exports = {
  '**/*.{ts,tsx,js,jsx,vue}': ['prettier --write', 'eslint --cache'],
};
