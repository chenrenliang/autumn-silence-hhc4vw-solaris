var expect = require('expect.js');

describe('测试功能', function () {
  it('测试用例', function () {
    expect(1).to.equal(1);
  });
});
