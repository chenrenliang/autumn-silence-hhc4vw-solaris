module.exports = {
  '**/*.js': ['eslint --cache'],
};
